<?php
/**
 * demo data.
 *
 * config.
 */
add_filter('ef3-theme-options-opt-name', 'wp_fcgroup_set_demo_opt_name');

function wp_fcgroup_set_demo_opt_name(){
    return 'opt_theme_options';
}

add_filter('ef3-replace-content', 'wp_fcgroup_replace_content', 10 , 2);

function wp_fcgroup_replace_content($replaces, $attachment){
    return array(
        //'/image="(.+?)"/' => 'image="'.$attachment.'"',
        '/tax_query:/' => 'remove_query:',
        '/categories:/' => 'remove_query:',
        //'/src="(.+?)"/' => 'src="'.ef3_import_export()->acess_url.'ef3-placeholder-image.jpg"'
    );
}

add_filter('ef3-replace-theme-options', 'wp_fcgroup_replace_theme_options');

function wp_fcgroup_replace_theme_options(){
    return array(
        'dev_mode' => 0,
    );
}
add_filter('ef3-enable-create-demo', 'wp_fcgroup_enable_create_demo');

function wp_fcgroup_enable_create_demo(){
    return false;
}